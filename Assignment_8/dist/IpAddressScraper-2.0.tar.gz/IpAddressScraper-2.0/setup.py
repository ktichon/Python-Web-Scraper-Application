from setuptools import setup
setup(
  name="IpAddressScraper",
  version="2.0",
  description="Get Ip address from a website",
  author="Kyle Tichon",
  author_email="ktichon@academic.rrc.ca",
  py_modules=["module_7a"],
)