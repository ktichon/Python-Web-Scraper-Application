from requests import get
import matplotlib.pyplot as plt
from dateutil import parser
import matplotlib.dates as mdates

weatherStations = [1572018, 2339720, 1356217]

for staion in weatherStations:
    url = 'https://apex.oracle.com/pls/apex/raspberrypi/weatherstation/getallmeasurements/' + str(staion)
    weather = get(url).json()

    data = weather['items']
    pages = 1
    while 'next' in weather and pages < 9:
        url = weather['next']['$ref']
        print('Fetching {0}'.format(url))
        weather = get(url).json()
        data += weather['items']
        pages += 1

    temperatures = [info['ambient_temp'] for info in data ]
    timestamps = [parser.parse(info['reading_timestamp']) for info in data]

    plt.plot(timestamps, temperatures)
plt.ylabel('Temperature')
plt.xlabel('Time')
plt.gcf().autofmt_xdate()
plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%b-%d'))

plt.show()

